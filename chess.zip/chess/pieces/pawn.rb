require_relative '../piece'

class Pawn

    def initialize(symbol, moves)
        @symbol = symbol

    end

    private

    def at_start_row?

    end

    def forward_dir

    end

    def forward_steps

    end

    def side_attacks

    end

    
end