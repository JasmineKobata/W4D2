class NullPiece

    def initialize
        
    end
end