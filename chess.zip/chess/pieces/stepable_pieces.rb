require_relative 'modules'
require_relative '../piece'

class Knight


    def symbol
        :k
    end
end

class King


    def symbol
        :K
    end
    
end